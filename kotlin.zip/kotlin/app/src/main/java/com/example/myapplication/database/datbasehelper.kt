package com.example.myapplication.database

import android.app.DownloadManager.Query
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.content.contentValuesOf

class databasehelper(context: Context): SQLiteOpenHelper(context, db_name , null,db_version) {
    companion object {
        private val db_name = "dbmbank"
        private val db_version = 1
        private val tb_name = "tbllcustomer"
        private val column1 = "id"
        private val column2 = "name"
        private val column3 = "acc_no"
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        val query =
            "create table $tb_name($column1 INTEGER PRIMARY KEY , $column2 TEXT,$column3 INTEGER)"
        p0?.execSQL(query)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val query = "DROP TABLE $tb_name"
        p0?.execSQL(query)
        onCreate(p0)
    }

    fun addcustomer(customerlist: customer): Boolean {
        var db = this.writableDatabase
        var values = ContentValues()
        values.put(column1, customerlist.id)
        values.put(column2, customerlist.name)
        values.put(column3, customerlist.acc_no)
        var result = db.insert(tb_name, null, values)

        if (Integer.parseInt(result.toString()) == -1) {
            return false
        } else {
            return true
        }
    }

    fun deletecustomer(customerlist: customer): Boolean {
        var db = this.writableDatabase
        var values = ContentValues()
        values.put(column1, customerlist.id)
        var result = db.delete(tb_name, "id=" + customerlist.id, null)
        if (Integer.parseInt(result.toString()) == -1) {
            return false
        } else {
            return true
        }
    }

    fun updatecustomer(customerlist: customer): Boolean {
        var db = this.writableDatabase
        var values = ContentValues()
        values.put(column1, customerlist.id)
        values.put(column2, customerlist.name)
        values.put(column3, customerlist.acc_no)
        var result = db.update(tb_name, values, "id =" + customerlist.id, null)

        if (Integer.parseInt(result.toString()) == -1) {
            return false
        } else {
            return true
        }
    }

    fun viewcustomer(): Cursor {
        var db=this.writableDatabase
        var cursor: Cursor?=null
        cursor=db.rawQuery("select * from $tb_name ",null)
        return cursor
    }

}