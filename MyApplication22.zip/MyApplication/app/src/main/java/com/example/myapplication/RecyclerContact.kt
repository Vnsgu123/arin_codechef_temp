package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerContact(private val titlist:List<Contactmodel>): RecyclerView.Adapter<RecyclerContact.Viewholder>() {
    class Viewholder(itemview: View) : RecyclerView.ViewHolder(itemview) {

        val textview1: TextView = itemview.findViewById(R.id.t1)
        val imageView : ImageView = itemview.findViewById(R.id.img)
        val textView2: TextView = itemview.findViewById(R.id.t2)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Viewholder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.contact_row,parent,false)
        return Viewholder(view)
    }

    override fun getItemCount(): Int {
        return titlist.count()
    }

    override fun onBindViewHolder(holder: Viewholder, position: Int) {

        val itemsViewModel = titlist[position]

        holder.imageView.setImageResource(itemsViewModel.image)
        holder.textview1.text = itemsViewModel.name
        holder.textView2.text = itemsViewModel.number

    }

}
