package com.example.myapplication.database

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.myapplication.R

class MainActivity : AppCompatActivity() {
    lateinit var txt1:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)


        val btnsave = findViewById<Button>(R.id.b1)
        val btndel = findViewById<Button>(R.id.b2)
        val btnupdate = findViewById<Button>(R.id.b3)
        val btnview = findViewById<Button>(R.id.b4)

        val txt1 = findViewById(R.id.e1) as EditText
        val txt2 = findViewById(R.id.e2) as EditText
        val txt3 = findViewById(R.id.e3) as EditText

        btnsave.setOnClickListener(View.OnClickListener {
            var databasehelper:databasehelper= databasehelper(this)

            var result:Boolean =databasehelper.addcustomer(customer(Integer.parseInt(txt1.text.toString()) , txt2.text.toString() ,txt3.text.toString()))
            if ( result ==true)
            {
                Toast.makeText(this , "SAVE data",Toast.LENGTH_LONG).show()
            }
        })

        btndel.setOnClickListener(View.OnClickListener {
            var databasehelper:databasehelper = databasehelper(this)

            var result = databasehelper.deletecustomer(customer(Integer.parseInt(txt1.text.toString()),"",""))

            if(result==true)
            {
                Toast.makeText(this,"data deleted",Toast.LENGTH_LONG).show()
            }

        })

        btnupdate.setOnClickListener(View.OnClickListener {
            var databasehelper:databasehelper = databasehelper(this)
            var result = databasehelper.updatecustomer(customer(Integer.parseInt(txt1.text.toString()),txt2.text.toString(),txt3.text.toString()))
            if (result == true)
            {
                Toast.makeText(this,"data updated",Toast.LENGTH_LONG).show()
            }
        })

        btnview.setOnClickListener(View.OnClickListener {
            intent = Intent(this,MainActivity2::class.java)
            startActivity(intent)

        })



    }





}