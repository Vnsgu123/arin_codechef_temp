package com.example.myapplication.database

data class customer(var id:Int,var name:String,var acc_no:String) {
}