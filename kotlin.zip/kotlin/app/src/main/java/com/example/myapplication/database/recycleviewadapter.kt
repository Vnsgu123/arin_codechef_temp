package com.example.myapplication.database

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.database.customer

class recycleviewadapter(private val customerlist:List<customer>) : RecyclerView.Adapter<recycleviewadapter.viewholder>() {
    class viewholder(custview : View) : RecyclerView.ViewHolder(custview)
    {
        val txtid:TextView=custview.findViewById(R.id.text1)

        val txtname:TextView=custview.findViewById(R.id.text2)
//        val txtano:TextView=custview.findViewById(R.id.e3)
    }
    override fun onCreateViewHolder(parent: ViewGroup,viewType: Int): viewholder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.listitem, parent, false)
        return viewholder(view)
    }
    override fun getItemCount(): Int
    {
        return customerlist.count()
    }
    override fun onBindViewHolder(holder: viewholder, position: Int) {
        val custlistmodel=customerlist[position]
        holder.txtid.text=custlistmodel.id.toString()
        holder.txtname.text=custlistmodel.name.toString()

//        holder.txtano.text=custlistmodel.acc_no.toString()
    }
}

//import android.view.View
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//
//class recycleviewadapter: RecyclerView.Adapter<RecyclerView.ViewHolder>() {
//    class ViewHolder(custview:View):RecyclerView.ViewHolder(custview)
//    {
//        val txtid:TextView = custview.findViewById(R.id.)
//
//
//    }
//}